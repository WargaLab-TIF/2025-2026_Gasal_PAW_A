<?php
 // Skrip dasar: foreach untuk menampilkan key dan value
 $height = array("Andy"=>"176", "Barry"=>"165", "Charlie"=>"170");
 foreach($height as $key => $value) {
 echo "Key= " . $key . ", Value= " . $value . "<br>";
 }
 ?>
<?php
$fruits = array("Avocado", "Blueberry " ,"Cherry ");
echo "i like " . $fruits [0] . "," . $fruits [1] . "and " . $fruits [2].".";
?>